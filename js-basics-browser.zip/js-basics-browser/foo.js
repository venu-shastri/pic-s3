(function(global){


function foo(){
    console.log("foo called");
}
//Project
global.philips={xyz:{ foo:foo} };

})(window);