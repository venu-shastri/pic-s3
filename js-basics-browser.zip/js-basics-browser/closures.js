(function(global){

    function foo(arg){

            let lv=arg;
//A-sync Call
            function checkStatus(){
    
            console.log(lv);
        }
            return checkStatus;
    }
    global.closures={foo:foo};
})(window);

