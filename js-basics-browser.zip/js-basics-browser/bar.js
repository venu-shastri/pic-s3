(function(global){

     //global.siemens={};
    // global.siemens.pqr={};
    // global.siemens.pqr.bar=bar;
function bar(){
    console.log("bar fun called");
}

global.siemens={
    pqr:{
        bar:bar
    }
};
})(window);