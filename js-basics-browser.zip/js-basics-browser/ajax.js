
function onSelectionChanged(){

    let  httpRequest=new XMLHttpRequest();
    
    //Register Callback
    httpRequest.onreadystatechange=function httpRequestStatusCallback(){

        //When Http request Status Changed
        //Waht is the current status (init,connection established,request accepted,processing,completed)
        if(httpRequest.readyState==4){
            //Compeletd
        }
    }
    //Prepare Request
    httpRequest.open("GET","getCities.json",true);
    //Request Submission
    httpRequest.send();//Non Blocking Call
}

