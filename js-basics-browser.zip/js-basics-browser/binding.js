function caller(){

    calle(); //default binding
    calle.apply(100);//explicit Binding
    calle.apply("hundred"); //explicit binding

    let obj1=new Student("S100","Tom");//new Binding
    let obj2=new Student("S200","Hary");//new Binding
    
    let id=obj1.getStudentId();//implicit Binding

    console.log(id);

    id=obj2.getStudentId();//implicit Binding
    console.log(id);
}
function calle(){

    let thisValue=this;
}
//Constructor
function Student(id,name){
    this._studentId=id;//private 
    this._studentName=name;//private
   
}
Student.prototype.getStudentId=function(){ 
    return this._studentId;
}

