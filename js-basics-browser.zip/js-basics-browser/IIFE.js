function foo(){

    var x=10;
    for(var i=0;i<10;i++){
        //Block
        (function(){
        var x=i+10;
        })();
    }
}