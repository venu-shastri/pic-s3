function add(x,y){

    var result=x+y;
}

//sub(20,10);
function sub(x,y)
{
    console.log(result);//undefined 
    var result=x-y;
    console.log(result);//10
}

//div(10,5);
function div(x,y)
{

    console.log(result);//undefined
    var result=100;
    if(y!=0){
        //if block

        var result=x/y;
        console.log(result);//2
    }
    console.log(result);//100
}

function newDiv(x,y){
    
    let result=100;
    if(y!=0){
        //if block

        let result=x/y;
        console.log(result);//2
    }
    console.log(result);//100
}

mul(10,2);
function mul(x,y){

    result=x*y;
}
