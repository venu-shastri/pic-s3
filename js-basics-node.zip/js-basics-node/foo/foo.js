function foo(){
    console.log("foo called");
}

module.exports=foo;