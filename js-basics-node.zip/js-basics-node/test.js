var barReference=require("./bar");//defualt - looks for index.js , if package.json exist and main key specified module loaded
require("./foo");//defualt - looks for index.js and loaded

var stringReference=require("string");//Modules from node_moduels folder Name

var name = stringReference('Your name is JP').right(2).toString(); //'JP'
console.log(name)
console.log("hello node");
barReference();
//fooReference();