function bar(){
    console.log("bar fun called");
}

module.exports=bar;